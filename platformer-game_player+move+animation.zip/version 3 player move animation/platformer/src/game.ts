import 'phaser'
import MainScene from './scenes/mainScene'
import PreloadScene from './scenes/preloadScene'
// @ts-ignore
import SpineWebGLPlugin from './plugins/SpineWebGLPlugin'


const DEFAULT_WIDTH: number = 1289
const DEFAULT_HEIGHT: number = 760


window.addEventListener('load', () => {
  const config: GameConfig = {
    type: Phaser.WEBGL,
    backgroundColor: '#ffffff',
    parent: 'phaser-game',
    scale: {
      // The game will be scaled manually in the resize()
      mode: Phaser.Scale.NONE,
      width: DEFAULT_WIDTH,
      height: DEFAULT_HEIGHT
    },
    plugins: {
      scene: [{ key: 'SpineWebGLPlugin', plugin: SpineWebGLPlugin, start: true, sceneKey: 'spine' }]
    },
    scene: [PreloadScene, MainScene],
    physics: {
      default: 'arcade',
      arcade: {
        debug: false,
        gravity: { y: 2500 }
      }
    }
  }

  const game = new Phaser.Game(config)

  
})
