
export default class MainScene extends Phaser.Scene {

 
  constructor() {
    super({
      key: 'MainScene'
    })
  }

  init() {

  }

  create() {
    
       // remove the loading screen
       let loadingScreen = document.getElementById('loading-screen')
       if (loadingScreen) {
         loadingScreen.classList.add('transparent')
         this.time.addEvent({
           delay: 1000,
           callback: () => {
             // @ts-ignore
             loadingScreen.remove()
           }
         })
       }
  }

  update() {

  }
}
