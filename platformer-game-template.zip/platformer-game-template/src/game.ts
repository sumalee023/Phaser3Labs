import 'phaser'
import MainScene from './scenes/mainScene'
import PreloadScene from './scenes/preloadScene'

const DEFAULT_WIDTH: number = 1289
const DEFAULT_HEIGHT: number = 760


window.addEventListener('load', () => {
  const config: GameConfig = {
    type: Phaser.AUTO,
    backgroundColor: '#ffffff',
    parent: 'phaser-game',
    scale: {
      mode: Phaser.Scale.NONE,
      width: DEFAULT_WIDTH,
      height: DEFAULT_HEIGHT
    },

    scene: [PreloadScene, MainScene],
    physics: {
      default: 'arcade',
      arcade: {
        debug: false,
        gravity: { y: 2500 }
      }
    }
  }

  const game = new Phaser.Game(config)

})
